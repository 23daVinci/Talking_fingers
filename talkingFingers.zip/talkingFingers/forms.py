from flask_wtf import FlaskForm
from wtforms import SelectField, SubmitField, TextField, FileField
from wtforms.validators import DataRequired

class MainForm(FlaskForm):
    fileName = FileField()
    location = TextField('Enter the location to store the files')
    algo = SelectField('Product', choices = [('Original', 'Original'), ('Canny', 'Canny'), ('Laplacian', 'Laplacian')], validators= [DataRequired()])
    submit = SubmitField('GO')